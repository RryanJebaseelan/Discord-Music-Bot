import discord
from discord.ext import commands
import music

cogs = [music]

client = commands.Bot(command_prefix='?', intents= discord.Intents.all())

for i in range(len(cogs)):
   cogs[i].setup(client)


client.run("ODg4MzU2MDY4MzkxMDI2NzI4.YURgDw.HSE3P5O__alFp46QBh3hOKzOvL4")